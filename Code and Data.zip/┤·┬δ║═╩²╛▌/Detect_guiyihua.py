from Em_guiyihua import *
import numpy as np
import math
from matplotlib import pyplot as plt
def Dectect_watermark(XLst, YLst, feature_num, X_sum, Y_sum, Lst_WaterMark):
    ListX_M, ListY_M = len(Lst_WaterMark) * [0], len(Lst_WaterMark) * [0]
    R = 20
    X_sum_Min = min(X_sum)
    Y_sum_Min = min(Y_sum)
    X_sum_Max = max(X_sum)
    Y_sum_Max = max(Y_sum)
    XLst_x, YLst_y = XLst, YLst

    for i in range(0, feature_num):
        for j in range(0, len(XLst[i])):
            if XLst[i][j] ==X_sum_Min or XLst[i][j] ==X_sum_Max:
                continue
            XLst[i][j] = ((XLst[i][j] - X_sum_Min) / (X_sum_Max - X_sum_Min)) * 1e10
            index_x = int(XLst_x[i][j] / 100) % len(Lst_WaterMark)  # 水印位索引
            if XLst[i][j] % R <= R / 2:
                ListX_M[index_x] += -1
            else:
                ListX_M[index_x] += 1

    for m in range(0, feature_num):
        for n in range(0, len(YLst[m])):
            if YLst[m][n]==Y_sum_Min or YLst[m][n]==Y_sum_Max:
                continue
            YLst[m][n] = (YLst[m][n] - Y_sum_Min) / (Y_sum_Max - Y_sum_Min) * 1e10

            index_y = int(YLst_y[m][n]/100) % len(Lst_WaterMark)
            if YLst[m][n] % R <= R / 2:
                ListY_M[index_y] += -1
            else:
                ListY_M[index_y] += 1
    for p in range(0, len(ListX_M)):
        if ListX_M[p] > 0:
            ListX_M[p] = 1
        else:
            ListX_M[p] = 0
    for q in range(0, len(ListY_M)):
        if ListY_M[q] > 0:
            ListY_M[q] = 1
        else:
            ListY_M[q] = 0
    return ListX_M, ListY_M

if __name__ == '__main__':
    Lst_WaterMark = [0, 1, 0, 1, 1, 1, 1, 0, 0, 1, 0, 1, 0, 1, 1, 0, 0, 1, 0, 1, 1, 0, 1, 0, 1, 0, 0]
    fn_r = r'D:\study\python\works\Paillier\guiyi.shp'
    XLst, YLst, PoLst,feature_num,X_sum,Y_sum= Read_XYPo_fromshp(fn_r)
    ListX_M, ListY_M = Dectect_watermark(XLst, YLst, feature_num, X_sum, Y_sum, Lst_WaterMark)
    print(ListX_M)
    print(ListY_M)
    print(Lst_WaterMark)





