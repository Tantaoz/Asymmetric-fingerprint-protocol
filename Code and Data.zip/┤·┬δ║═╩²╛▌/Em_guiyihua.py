import numpy as np
import cv2
from Read_Write import *

'''读入矢量数据（shp）'''


def Read_XYPo_fromshp(ori_shp):
    ds = ogr.Open(ori_shp, 0)
    layer = ds.GetLayer(0)
    feature_num = layer.GetFeatureCount()
    XLst, YLst, PoLst, X_sum, Y_sum = [], [], [], [], []
    for in_feature in layer:
        geom = in_feature.geometry()  # 图层要素数据
        wkt = geom.ExportToWkt()  # 查看数据(Wkt给人看，Wkb给计算机看)
        pointstring = wkt[wkt.find('(') + 1:wkt.rfind(')')].split(',')  # 返回分割后的字符串列表。
        x, y, po = [], [], []
        for point_value in pointstring:
            xy = point_value.split(' ')
            x += [float(xy[0])]
            y += [float(xy[1])]
            po += [(float(xy[0]), float(xy[1]))]
        X_sum += x  # 总的X坐标集合
        Y_sum += y
        XLst.append(x), YLst.append(y), PoLst.append(po)  # 每一线要素中X，Y和点列表构成的列表集合
    ds.Destroy()
    return XLst, YLst, PoLst, feature_num, X_sum, Y_sum


'''写出矢量数据'''


def Write_XYPo_toshp(ori_shp, en_shp, XLst_emb, YLst_emb):
    ds = ogr.Open(ori_shp, 0)  # 0是只读，为1是可写
    in_layer = ds.GetLayer(0)
    feature_num = in_layer.GetFeatureCount()
    driver = ogr.GetDriverByName('ESRI Shapefile')  # 传递驱动驱动程序
    data_source = driver.CreateDataSource(en_shp)  # 创建新文件（srs：新建图层空间参考系统，默认为空，表示未设置任何空间参考系统）
    get_srs = in_layer.GetSpatialRef()  # 获取参考系统
    out_layer = data_source.CreateLayer(en_shp, get_srs, ogr.wkbLineString)  # 创建新shp图层
    out_layer.CreateFields(in_layer.schema)  # 继承in_layer的属性（schema属性会获得图层FieldDefn对象列表）
    out_defn = out_layer.GetLayerDefn()  # 获取取out_layer图层定义信息，获取这个layer的信息表格
    if os.access(en_shp, os.F_OK):  # path 为路径，os.F_OK测试path是否存在。
        driver.DeleteDataSource(en_shp)  # 若存在 删除
    feat_count = 0
    for in_feature in in_layer:  # 遍历原始数据图层要素
        geom = in_feature.geometry()  # 查看原始数据图层要素数据
        wkt = geom.ExportToWkt()  # 查看数据(Wkt给人看，Wkb给计算机看)
        pointstring = wkt[wkt.find('(') + 1:wkt.rfind(')')].split(',')
        pts_new = ''  # 创建一个空字符串
        point_num = 0
        for point_value in pointstring:
            xy = point_value.split(' ')  # 返回分割后的字符串列表。
            x = float(xy[0])
            y = float(xy[1])
            en_x = XLst_emb[feat_count][point_num]
            en_y = YLst_emb[feat_count][point_num]
            pts_new += str(en_x) + ' ' + str(en_y) + ','
            point_num += 1
        en_wkt = wkt[0:wkt.find('(') + 1] + pts_new[:-1] + ')'
        out_feature = ogr.Feature(out_defn)  # 读取相应的feature类型，并创建feature
        en_Geometry = ogr.CreateGeometryFromWkt(en_wkt)  # 创建几何对象，这里是线
        out_feature.SetGeometry(en_Geometry)  # 设定几何形状
        for i in range(1, in_feature.GetFieldCount()):  # 得到字段数目,不包括最前面的两个字段(FID,shape),在arcgis里面这两个字段不能被改变
            value = in_feature.GetField(i)  # 获取原始数据某个字段的值
            out_feature.SetField(i, value)  # 设定输出数据某字段的数值
        out_layer.CreateFeature(out_feature)  # 将feature写入layer
        feat_count += 1
    ds.Destroy()


'''嵌入水印'''


def Embed_Watermark(XLst, YLst, Lst_WaterMark, feature_num, X_sum, Y_sum):
    # 最大最小归一化，映射函数，QIM嵌入
    XLst_x, YLst_y = XLst, YLst
    R = 20
    X_sum_Min = min(X_sum)
    Y_sum_Min = min(Y_sum)
    X_sum_Max = max(X_sum)
    Y_sum_Max = max(Y_sum)
    # X坐标嵌入水印
    for i in range(0, feature_num):
        for j in range(0, len(XLst[i])):  # 遍历每个对象中的X元素
            if XLst[i][j] == X_sum_Min or XLst[i][j] == X_sum_Max:
                continue
            XLst[i][j] = ((XLst[i][j] - X_sum_Min) / (X_sum_Max - X_sum_Min)) * 1e10  # 归一化放大10**7倍
            index_x = int(XLst_x[i][j] / 100) % len(Lst_WaterMark)  # 水印位索引
            #  水印嵌入
            if Lst_WaterMark[index_x] == 0 and XLst[i][j] % R > R / 2:
                XLst[i][j] = XLst[i][j] - R / 2
            elif Lst_WaterMark[index_x] == 0 and XLst[i][j] % R <= R / 2:
                XLst[i][j] = XLst[i][j]
            elif Lst_WaterMark[index_x] == 1 and XLst[i][j] % R <= R / 2:
                XLst[i][j] = XLst[i][j] + R / 2
            else:
                XLst[i][j] = XLst[i][j]
            # 反归一化
            XLst[i][j] = (XLst[i][j]) / 1e10 * (X_sum_Max - X_sum_Min) + X_sum_Min
        # Y坐标嵌入水印
    for m in range(0, feature_num):
        for n in range(0, len(YLst[m])):
            if YLst[m][n] == Y_sum_Min or YLst[m][n] == Y_sum_Max:
                continue
            YLst[m][n] = (YLst[m][n] - Y_sum_Min) / (Y_sum_Max - Y_sum_Min) * 1e10
            index_y = int(YLst_y[m][n]/100) % len(Lst_WaterMark)
            if Lst_WaterMark[index_y] == 0 and YLst[m][n] % R > R / 2:
                YLst[m][n] = YLst[m][n] - R / 2
            elif Lst_WaterMark[index_y] == 0 and YLst[m][n] % R <= R / 2:
                YLst[m][n] = YLst[m][n]
            elif Lst_WaterMark[index_y] == 1 and YLst[m][n] % R <= R / 2:
                YLst[m][n] = YLst[m][n] + R / 2
            else:
                YLst[m][n] = YLst[m][n]
            # 反归一化
            YLst[m][n] = (YLst[m][n] / 1e10 * (Y_sum_Max - Y_sum_Min) + Y_sum_Min)
    return XLst, YLst

if __name__ == '__main__':
    Lst_WaterMark = [0, 1, 0, 1, 1, 1, 1, 0, 0, 1, 0, 1, 0, 1, 1, 0, 0, 1, 0, 1, 1, 0, 1, 0, 1, 0, 0]
    fn_r = r'D:\study\python\works\Paillier\polyline1.shp'
    XLst, YLst, PoLst,feature_num,X_sum,Y_sum= Read_XYPo_fromshp(fn_r)  # 读取原始矢量数据
    XLst_emb, YLst_emb = Embed_Watermark(XLst, YLst, Lst_WaterMark, feature_num, X_sum, Y_sum)  # 嵌入水印
    fn_w = r'D:\study\python\works\Paillier\guiyi.shp'
    write_encrytpion_shp(fn_r, fn_w, XLst_emb, YLst_emb)  # 写出嵌入水印后的矢量数据
    print("finish")
