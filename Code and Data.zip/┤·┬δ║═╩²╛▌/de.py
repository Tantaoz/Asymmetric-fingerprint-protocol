import copy
from Read_Write import *
import math
from en import *

def Dectect_watermark(XLst_zs,YLst_zs, feature_num,Lst_WaterMark):
    ListX_M, ListY_M = len(Lst_WaterMark) * [0], len(Lst_WaterMark) * [0]

    for i in range(0,feature_num):
        for j in range(0,len(XLst_zs[i])):
            fx=int(XLst_zs[i][j]/10)
            index_x = fx % len(Lst_WaterMark)
            if XLst_zs[i][j]%2==1:
                ListX_M[index_x] = ListX_M[index_x] + 1
            else:
                ListX_M[index_x] = ListX_M[index_x] - 1

    for m in range(0, feature_num):
        for n in range(0, len(YLst_zs[m])):
            fy=int(YLst_zs[m][n]/10)
            index_y = fy % len(Lst_WaterMark)
            if (YLst_zs[m][n]%2)==1:
                ListY_M[index_y] = ListY_M[index_y] + 1
            else:
                ListY_M[index_y] = ListY_M[index_y]-1

    for p in range(0, len(ListX_M)):
        if ListX_M[p] > 0:
            ListX_M[p] = 1
        else:
            ListX_M[p] = 0
    for q in range(0, len(ListY_M)):
        if ListY_M[q] > 0:
            ListY_M[q] = 1
        else:
            ListY_M[q] = 0

    return ListX_M, ListY_M

def zhengshu1(XLst,YLst,qn):
    XLst1 = copy.deepcopy(XLst)
    YLst1 = copy.deepcopy(YLst)
    for i in range(len(XLst)):
        for j in range(len(XLst[i])):
            XLst1[i][j] = round((XLst[i][j]) / qn)
    for m in range(len(YLst)):
        for n in range(len(YLst[m])):
            YLst1[m][n] = round((YLst[m][n]) / qn)
    return XLst1, YLst1

if __name__ == '__main__':
    Lst_WaterMark = [0, 1, 1, 0, 1, 0, 1, 0, 0, 1, 1, 1, 0, 1, 1, 1, 0, 0, 0, 1, 0, 0, 1, 0, 1, 0, 0]
    fn_r = r'D:\study\python\works\Paillier\mingwenditu.shp'
    fjmXLst, fjmYLst,PoLst2, feature_num1, X_sum2, Y_sum2 = Read_XYPo_fromshp(fn_r)

    index_x1, index_y1, index_x2, index_y2=cankaodian(fjmXLst,feature_num1,X_sum2)

    q_x = (fjmXLst[index_x1][index_y1] + fjmXLst[index_x2][index_y2]) / 2
    q_y = (fjmYLst[index_x1][index_y1] + fjmYLst[index_x2][index_y2]) / 2

    a=math.atan((fjmYLst[index_x2][index_y2]-fjmYLst[index_x1][index_y1])/(fjmXLst[index_x2][index_y2]-fjmXLst[index_x1][index_y1]))
    p = 0.00001
    qn=p*(math.sqrt((fjmXLst[index_x2][index_y2]-fjmXLst[index_x1][index_y1])**2+(fjmYLst[index_x2][index_y2]-fjmYLst[index_x1][index_y1])**2))

    XLst_xd, YLst_xd = xiangdui(fjmXLst, fjmYLst, q_x, q_y, feature_num1, a)
    XLst_zs, YLst_zs = zhengshu1(XLst_xd, YLst_xd, qn)

    ListX_M, ListY_M = Dectect_watermark(XLst_zs, YLst_zs ,feature_num1, Lst_WaterMark)

    print(ListX_M)
    print(ListY_M)
    print(Lst_WaterMark)



