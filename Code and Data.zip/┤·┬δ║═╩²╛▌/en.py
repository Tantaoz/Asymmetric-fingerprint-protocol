import copy
from Read_Write import *
import math
from Paillier2 import *
import numpy as np

def xiangdui(XLst2,YLst2, q_x,q_y, feature_num2,a):
    XLst=copy.deepcopy(XLst2)
    YLst=copy.deepcopy(YLst2)
    for i in range(feature_num2):
        for j in range(len(XLst2[i])):
            XLst[i][j] = (XLst2[i][j] - q_x) * math.cos(a) + (YLst2[i][j] - q_y) * math.sin(a)
            YLst[i][j] = (YLst2[i][j] - q_y) * math.cos(a) - (XLst2[i][j] - q_x) * math.sin(a)
    return XLst,YLst

def zhengshu(XLst,YLst,qn):
    XLst1 = copy.deepcopy(XLst)
    YLst1 = copy.deepcopy(YLst)
    for i in range(len(XLst)):
        for j in range(len(XLst[i])):
            if int(XLst[i][j]/qn)%2==0:
                XLst1[i][j] = int(XLst[i][j] / qn)
            elif int(XLst[i][j]/qn)%2==1:
                if(XLst[i][j]>0):
                    XLst1[i][j] = int(XLst[i][j] / qn) + 1
                else:
                    XLst1[i][j] = int(XLst[i][j] / qn) - 1

    for m in range(len(YLst)):
        for n in range(len(YLst[m])):
            if int(YLst[m][n]/qn)%2==0:
                YLst1[m][n] = int(YLst[m][n] / qn)
            elif int(YLst[m][n]/qn)%2==1:
                if(YLst[m][n]>0):
                    YLst1[m][n] = int(YLst[m][n] / qn) + 1
                else:
                    YLst1[m][n] = int(YLst[m][n] / qn) - 1

    return XLst1, YLst1

def cankaodian(XLst2,feature_num2,X_sum):
    zx1_x = max(X_sum)
    index_x1 = 0
    index_y1 = 0
    zx2_x = min(X_sum)
    index_x2 = 0
    index_y2 = 0
    for i in range(feature_num2):
        for j in range(len(XLst2[i])):
            if XLst2[i][j] == zx1_x:
                index_x1 = i
                index_y1 = j
    for i in range(feature_num2):
        for j in range(len(XLst2[i])):
            if XLst2[i][j] == zx2_x:
                index_x2 = i
                index_y2 = j
    return index_x1,index_y1,index_x2,index_y2

def encryptmap(XLst_zs,YLst_zs):
    newXLst = copy.deepcopy(XLst_zs)
    newYLst = copy.deepcopy(YLst_zs)
    for i in range(len(XLst_zs)):
        for j in range(len(XLst_zs[i])):
            if(XLst_zs[i][j]<0):
                newXLst[i][j]=encrypt(pk,abs(XLst_zs[i][j]))*(-1)
            elif(XLst_zs[i][j]>=0):
                newXLst[i][j]=encrypt(pk,abs(XLst_zs[i][j]))
    for i in range(len(YLst_zs)):
        for j in range(len(YLst_zs[i])):
            if (YLst_zs[i][j] < 0):
                newYLst[i][j]=encrypt(pk,abs(YLst_zs[i][j]))*(-1)
            elif (YLst_zs[i][j] >= 0):
                newYLst[i][j]=encrypt(pk,abs(YLst_zs[i][j]))
    return newXLst,newYLst

def en(encryptXLst,encryptYLst,index_x1, index_y1, index_x2, index_y2,XLst_zs,YLst_zs,encrypt_WaterMark):
    wXLst = copy.deepcopy(encryptXLst)
    wYLst = copy.deepcopy(encryptYLst)
    for i in range(len(encryptXLst)):
        for j in range(len(encryptXLst[i])):
            if (i==index_x1 and j==index_y1) or (i==index_x2 and j==index_y2):
                continue
            fx=int(XLst_zs[i][j]/10)
            index_x=fx%len(encrypt_WaterMark)
            wXLst[i][j] = encryptXLst[i][j] * encrypt_WaterMark[index_x]
    for m in range(len(encryptYLst)):
        for n in range(len(encryptYLst[m])):
            if (m==index_x1 and n==index_y1) or (m==index_x2 and n==index_y2):
                continue
            fy=int(YLst_zs[m][n]/10)
            index_y=fy%len(encrypt_WaterMark)
            wYLst[m][n] = encryptYLst[m][n] * encrypt_WaterMark[index_y]
    return wXLst,wYLst

def decryptmap(wXLst,wYLst,qn,a,q_x,q_y):
    jmXLst = copy.deepcopy(wXLst)
    jmYLst = copy.deepcopy(wYLst)
    fjmXLst = copy.deepcopy(wXLst)
    fjmYLst = copy.deepcopy(wYLst)
    for i in range(len(wXLst)):
        for j in range(len(wXLst[i])):
            if (wXLst[i][j] < 0):
                jmXLst[i][j] = decrypt(sk, pk, abs(wXLst[i][j])) * (-1)
            elif (wXLst[i][j] >= 0):
                jmXLst[i][j] = decrypt(sk, pk, abs(wXLst[i][j]))
    for m in range(len(wYLst)):
        for n in range(len(wYLst[m])):
            if (wYLst[m][n] < 0):
                jmYLst[m][n] = decrypt(sk, pk, abs(wYLst[m][n])) * (-1)
            elif (wYLst[m][n] >= 0):
                jmYLst[m][n] = decrypt(sk, pk, abs(wYLst[m][n]))
    for p in range(len(jmXLst)):
        for q in range(len(jmXLst[p])):
            fjmXLst[p][q] = (jmXLst[p][q] * qn) * math.cos(-a) + (jmYLst[p][q] * qn) * math.sin(-a) + q_x
            fjmYLst[p][q] = (jmYLst[p][q] * qn) * math.cos(-a) - (jmXLst[p][q] * qn) * math.sin(-a) + q_y
    return fjmXLst,fjmYLst

if __name__ == '__main__':
    Lst_WaterMark = [0, 1, 1, 0, 1, 0, 1, 0, 0, 1, 1, 1, 0, 1, 1, 1, 0, 0, 0, 1, 0, 0, 1, 0, 1, 0, 0]
    fn_r = r'D:\study\python\works\Paillier\polyline1.shp'
    XLst2, YLst2, PoLst,feature_num2,X_sum,Y_sum = Read_XYPo_fromshp(fn_r)

    index_x1, index_y1, index_x2, index_y2=cankaodian(XLst2,feature_num2,X_sum)

    q_x=(XLst2[index_x1][index_y1]+XLst2[index_x2][index_y2])/2
    q_y=(YLst2[index_x1][index_y1]+YLst2[index_x2][index_y2])/2
    a=math.atan((YLst2[index_x2][index_y2]-YLst2[index_x1][index_y1])/(XLst2[index_x2][index_y2]-XLst2[index_x1][index_y1]))
    p=0.00001
    qn=p*(math.sqrt((XLst2[index_x2][index_y2]-XLst2[index_x1][index_y1])**2+(YLst2[index_x2][index_y2]-YLst2[index_x1][index_y1])**2))
    XLst_xd, YLst_xd = xiangdui(XLst2, YLst2, q_x, q_y, feature_num2, a)
    XLst_zs,YLst_zs=zhengshu(XLst_xd,YLst_xd,qn)

    encryptXLst,encryptYLst=encryptmap(XLst_zs,YLst_zs)

    encrypt_WaterMark=[]
    for i in range(len(Lst_WaterMark)):
        encrypt_WaterMark.append(encrypt(pk,Lst_WaterMark[i]))
    wXLst,wYLst=en(encryptXLst,encryptYLst,index_x1, index_y1, index_x2, index_y2,XLst_zs,YLst_zs,encrypt_WaterMark)
    fn_w1 = r'D:\study\python\works\Paillier\miwenditu.shp'
    write_encrytpion_shp(fn_r, fn_w1, wXLst, wYLst)

    jmXLst,jmYLst=decryptmap(wXLst,wYLst,qn,a,q_x,q_y)
    fn_w2 = r'D:\study\python\works\Paillier\mingwenditu.shp'
    write_encrytpion_shp(fn_r, fn_w2, jmXLst, jmYLst)


